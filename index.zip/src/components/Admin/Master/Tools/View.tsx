import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
    FiTool, FiCalendar,
} from 'react-icons/fi';
import {
    FaIdCard, FaToolbox, FaFileContract, FaHashtag, FaRegCalendarCheck,
    FaCalendarAlt,
    FaUserTie, FaHistory, FaFilePdf
} from 'react-icons/fa';
import { HiCpuChip } from 'react-icons/hi2';
import dayjs from 'dayjs';
import { getByToolId, toolHistory } from '../../../../api';

interface ToolType {
    nomenclature: string;
    manufacture_date: string;
    model: string;
    SrNo: string;
    calibrationCertificateNo: string;
    calibrationValidTill: string;
    range: string;
    toolId: string;
    certificate: string;
    engineerName?: string;
    issueDate?: string;
    submitDate?: string;
}

const View: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const [tool, setTool] = useState<ToolType | null>(null);
    const [history, setHistory] = useState<{ engineerName: string; issueDate: string; submitDate: string } | null>(null);

    useEffect(() => {
        const fetchTool = async () => {
            if (!id) return;

            try {
                const res = await getByToolId(id);
                console.log("🚀 ~ fetchTool ~ res:", res)
                if (res?.data) {
                    setTool(res.data);
                }
            } catch (error) {
                console.error("❌ Error fetching tool by ID:", error);
            }
        };

        const fetchHistory = async () => {
            if (!id) return;

            try {
                const res = await toolHistory(id);
                if (res?.data) {
                    setHistory({
                        engineerName: res.data.engineer?.name || "-",
                        issueDate: res.data.issueDate ? dayjs(res.data.issueDate).format("DD-MM-YYYY") : "-",
                        submitDate: res.data.submitDate ? dayjs(res.data.submitDate).format("DD-MM-YYYY") : "-",
                    });
                }
            } catch (error) {
                console.error("❌ Error fetching tool history:", error);
            }
        };

        fetchTool();
        fetchHistory();
    }, [id]);

    if (!tool) return <div className="p-6 text-gray-600">Loading...</div>;

    return (
        <div className="p-6">
            {/* Breadcrumbs */}
            <ol className="flex text-gray-500 font-semibold dark:text-white-dark mb-4">
                <li>
                    <Link to="/" className="hover:text-gray-500/70 dark:hover:text-white-dark/70">
                        Dashboard
                    </Link>
                </li>
                <li className="before:w-1 before:h-1 before:rounded-full before:bg-primary before:inline-block before:relative before:-top-0.5 before:mx-4">
                    <Link to="/admin/tools" className="text-primary">
                        Tools
                    </Link>
                </li>
                <li className="before:w-1 before:h-1 before:rounded-full before:bg-primary before:inline-block before:relative before:-top-0.5 before:mx-4">
                    <Link to="#" className="hover:text-gray-500/70 dark:hover:text-white-dark/70">
                        View Tool
                    </Link>
                </li>
            </ol>

            {/* Tool Details */}
            <div className="bg-white rounded-xl shadow-xl p-8">
                <div className="mb-8 flex items-center gap-3">
                    <FiTool className="text-primary text-2xl" />
                    <h1 className="text-2xl font-bold text-gray-800">Tool Details</h1>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-sm text-gray-700">
                    <Detail label="Tool ID" value={tool.toolId} icon={<FaIdCard />} />
                    <Detail label="Tool Name" value={tool.nomenclature} icon={<FaToolbox />} />
                    <Detail label="Model" value={tool.model} icon={<HiCpuChip />} />
                    <Detail label="Serial No" value={tool.SrNo} icon={<FaHashtag />} />
                    <Detail label="Calibration Certificate No" value={tool.calibrationCertificateNo} icon={<FaFileContract />} />
                    {tool.certificate && (
                        <Detail
                            label="Certificate"
                            value={
                                <a
                                    href={tool.certificate}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="text-blue-600 hover:underline break-all"
                                >
                                    View Certificate (PDF)
                                </a>
                            }
                            icon={<FaFilePdf />}
                        />
                    )}
                    <Detail label="Calibration Valid Till" value={dayjs(tool.calibrationValidTill).format('DD-MM-YYYY')} icon={<FaRegCalendarCheck />} />
                    <Detail label="Manufacture Date" value={dayjs(tool.manufacture_date).format('DD-MM-YYYY')} icon={<FiCalendar />} />
                    <Detail label="Range" value={tool.range} icon={<FiTool />} />
                </div>
            </div>

            {/* Tool History */}
            <div className="bg-white rounded-xl shadow-xl p-8 mt-10">
                <div className="mb-8 flex items-center gap-3">
                    <FaHistory className="text-primary text-2xl" />
                    <h1 className="text-2xl font-bold text-gray-800">History</h1>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-sm text-gray-700">
                    <Detail label="Engineer Name" value={history?.engineerName || "-"} icon={<FaUserTie className="text-primary" />} />
                    <Detail label="Issue Date" value={history?.issueDate || "-"} icon={<FaCalendarAlt />} />
                    <Detail label="Submit Date" value={history?.submitDate || "-"} icon={<FaCalendarAlt />} />
                </div>
            </div>
        </div>
    );
};

interface DetailProps {
    label: string;
    value: React.ReactNode;
    icon?: React.ReactNode;
}

const Detail: React.FC<DetailProps> = ({ label, value, icon }) => (
    <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 shadow-sm">
        <div className="text-xs uppercase text-gray-500 font-semibold mb-1 flex items-center gap-2">
            {icon && <span className="text-primary">{icon}</span>}
            {label}
        </div>
        <div className="text-gray-800 font-medium">{value}</div>
    </div>
);

export default View;