"use client"
import type React from "react"
import { useState, useEffect } from "react"
import { Link, useNavigate, useParams } from "react-router-dom"
import { Edit, Trash2, Building2, Eye, Search } from "lucide-react"
import * as Yup from "yup"
import { Field, Form, Formik } from "formik"
import {
  getAllClients,
  getAllHospitalsByClientId,
  deleteHospitalByClientIdAndHospitalId,
  createHospitalByClientId,
} from "../../../../api"
import { showMessage } from "../../../common/ShowMessage"
import FullScreenLoader from "../../../common/FullScreenLoader"
import ConfirmModal from '../../../../components/common/ConfirmModal';


// Define interfaces
interface Hospital {
  id: number
  _id?: string // MongoDB ID if using MongoDB
  name: string
  address: string
  phone: string
  email?: string
  licenseNo?: string
  gstNo: string
  branch: string
}

interface Equipment {
  id: number
  machineType: string
  model: string
  make: string
  serialNo: string
  equipID: string
  qaValidity: string
  licenseValidity: string
  status: string
  qaReportAttachment: string
  licenceAttachment: string
}

interface Client {
  id: number
  name: string
  email: string
  address: string
  phone: string
  business: string
  gstNo: string
  hospitals: Hospital[]
  equipment: Equipment[]
}

const ViewClients: React.FC = () => {
  const navigate = useNavigate()
  const { clientId } = useParams()
  console.log("🚀 ~ ViewClients ~ clientId:", clientId)

  const [clients, setClients] = useState<Client[]>([])
  const [hospitals, setHospitals] = useState<Hospital[]>([])
  const [selectedClient, setSelectedClient] = useState<Client | null>(null)
  const [loading, setLoading] = useState(true)
  const [deleteLoading, setDeleteLoading] = useState(false)
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [deleteItem, setDeleteItem] = useState<{ type: string; id: number | string; name: string } | null>(null)
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 5
  const [searchTerm, setSearchTerm] = useState("");

  const SubmittedForm = Yup.object().shape({
    name: Yup.string().required("Please fill the Field"),
    address: Yup.string().required("Please fill the Field"),
    phone: Yup.string()
      .matches(/^[0-9]{10}$/, "Phone number must be exactly 10 digits")
      .required("Please fill the Field"),
    gstNo: Yup.string(),
    branch: Yup.string().required("Please fill the Field"),
    email: Yup.string().email('Invalid email').required('Please fill the Email'),
  })

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch clients data
        const clientsRes = await getAllClients()
        console.log("🚀 ~ fetchClients ~ res:", clientsRes.data.clients)
        setClients(clientsRes?.data?.clients || [])

        // If clientId is provided, fetch hospital data
        if (clientId) {
          await fetchClientData(clientId)
        }
      } catch (error) {
        console.error("Error fetching data:", error)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [clientId])

  useEffect(() => {
    setCurrentPage(1)
  }, [hospitals])

  const fetchClientData = async (id: string) => {
    try {
      const hospitalData = await getAllHospitalsByClientId(id)
      console.log("Hospitals:", hospitalData)
      // Update state with fetched data
      setHospitals(hospitalData.data || [])
    } catch (error) {
      console.error("Error fetching hospital data:", error)
      // Set empty array on error
      setHospitals([])
    }
  }

  const handleViewClient = async (client: Client) => {
    setSelectedClient(client)
    await fetchClientData(client.id.toString())
  }

  const handleEditHospital = (hospitalId: number | string) => {
    console.log("Navigating to edit hospital with ID:", hospitalId)
    navigate(`/admin/clients/preview/${clientId}/edit-hospital/${hospitalId}`)
  }

  const handleViewHospital = (hospitalId: number | string) => {
    navigate(`/admin/clients/preview/${clientId}/${hospitalId}`)
  }

  const handleDeleteClick = (id: number | string, name: string) => {
    setDeleteItem({ type: "hospital", id, name })
    setShowDeleteModal(true)
  }

  const handleDeleteConfirm = async () => {
    if (!deleteItem || !clientId) return;

    setDeleteLoading(true);
    try {
      const res = await deleteHospitalByClientIdAndHospitalId(clientId, deleteItem.id);
      console.log("Delete API response:", res);

      setHospitals((prev) =>
        prev.filter((h) => String(h._id || h.id) !== String(deleteItem.id))
      );

      showMessage("Hospital deleted successfully!", "success");
      setShowDeleteModal(false);
      setDeleteItem(null);
    } catch (error: any) {
      console.error("Error deleting hospital:", error);
      const message = error?.response?.data?.message || "Failed to delete hospital";
      showMessage(message, "error");
    } finally {
      setDeleteLoading(false);
    }
  };

  const indexOfLast = currentPage * itemsPerPage;
  const indexOfFirst = indexOfLast - itemsPerPage;
  // const currentHospitals = hospitals.slice(indexOfFirst, indexOfLast);
  // Filter hospitals by name
  const filteredHospitals = hospitals.filter((h) =>
    h.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Pagination after search
  const currentHospitals = filteredHospitals.slice(indexOfFirst, indexOfLast);

  // Update total pages
  const totalPages = Math.ceil(filteredHospitals.length / itemsPerPage);

  // const totalPages = Math.ceil(hospitals.length / itemsPerPage);

  if (loading) {
    return <div className="flex justify-center items-center h-64">Loading...</div>
  }

  return (
    <>
      {deleteLoading && <FullScreenLoader message="Deleting hospital, please wait..." />}
      <div className="container mx-auto p-6">
        {/* Breadcrumb */}
        <nav className="flex text-sm text-gray-500 mb-6">
          <Link to="/" className="hover:text-gray-700">
            Dashboard
          </Link>
          <span className="mx-2">/</span>
          <Link to="/admin/clients" className="hover:text-gray-700">
            Clients
          </Link>
          <span className="mx-2">/</span>
          <span className="text-gray-900">View Client Hospitals</span>
        </nav>
        <div className="grid grid-cols-1 md:grid-cols-1 gap-6 mb-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <Building2 className="h-8 w-8 text-blue-500" />
              <div className="ml-4">
                <h3 className="text-lg font-semibold text-gray-900">Total Hospitals</h3>
                <p className="text-2xl font-bold text-blue-600">{hospitals.length}</p>
              </div>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-md mb-6">

          <div className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Add New Hospital</h3>
            <Formik
              initialValues={{
                name: "",
                address: "",
                phone: "",
                gstNo: "",
                branch: "",
                email: "",
              }}
              validationSchema={SubmittedForm}
              onSubmit={async (values, { setSubmitting, setFieldError, resetForm }) => {
                setLoading(true)
                try {
                  const response = await createHospitalByClientId(clientId, values)
                  console.log("🚀 ~ onSubmit={ ~ response:", response)
                  showMessage("Hospital added successfully!", "success")
                  resetForm()
                  // Refresh hospital data
                  await fetchClientData(clientId!)
                } catch (error: any) {
                  const message = error?.response?.data?.message
                  console.log("🚀 ~ onSubmit ~ message:", message)
                  if (message?.includes("phone")) {
                    setFieldError("phone", message)
                  } else if (message?.includes("gstNo")) {
                    setFieldError("gstNo", message)
                  } else {
                    showMessage(message || "Failed to add hospital", "error")
                  }
                } finally {
                  setSubmitting(false)
                  setLoading(false)
                }
              }}
            >
              {({ errors, submitCount, touched }) => (
                <Form className="space-y-5">

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                    <div className={submitCount ? (errors.name ? "has-error" : "has-success") : ""}>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                        Name
                      </label>
                      <Field
                        name="name"
                        type="text"
                        id="name"
                        placeholder="Enter Hospital Name"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      {submitCount && errors.name ? (
                        <div className="text-red-500 text-sm mt-1">{errors.name}</div>
                      ) : null}
                    </div>
                    <div className={submitCount ? (errors.address ? "has-error" : "has-success") : ""}>
                      <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
                        Address
                      </label>
                      <Field
                        name="address"
                        type="text"
                        id="address"
                        placeholder="Enter Address"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      {submitCount && errors.address ? (
                        <div className="text-red-500 text-sm mt-1">{errors.address}</div>
                      ) : (
                        ""
                      )}
                    </div>
                    <div className={submitCount ? (errors.phone ? "has-error" : "has-success") : ""}>
                      <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                        Phone
                      </label>
                      <Field
                        name="phone"
                        type="text"
                        id="phone"
                        placeholder="Enter Phone Number"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        maxLength={10}
                        onInput={(e: React.ChangeEvent<HTMLInputElement>) => {
                          e.target.value = e.target.value.replace(/\D/g, "").slice(0, 10); // only digits, max 10
                        }}
                      />
                      {submitCount && errors.phone ? (
                        <div className="text-red-500 text-sm mt-1">{errors.phone}</div>
                      ) : (
                        ""
                      )}
                    </div>
                    <div className={submitCount ? (errors.gstNo ? 'has-error' : 'has-success') : ''}>
                      <label htmlFor="gstNo">GST Number </label>
                      <Field name="gstNo">
                        {({
                          field,
                          form,
                        }: {
                          field: { name: string; value: string; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; onBlur: (e: React.FocusEvent<HTMLInputElement>) => void };
                          form: { setFieldValue: (field: string, value: any, shouldValidate?: boolean) => void };
                        }) => (
                          <input
                            {...field}
                            type="text"
                            id="gstNo"
                            placeholder="Enter GST Number"
                            className="form-input"
                            maxLength={15}
                            onChange={(e) => {
                              // Allow only uppercase letters and digits
                              const value = e.target.value.toUpperCase().replace(/[^0-9A-Z]/g, '');
                              form.setFieldValue(field.name, value);
                            }}
                          />
                        )}
                      </Field>
                      {submitCount && errors.gstNo ? (
                        <div className="text-danger mt-1">{errors.gstNo as string}</div>
                      ) : null}
                    </div>
                    <div className={submitCount ? (errors.branch ? "has-error" : "has-success") : ""}>
                      <label htmlFor="branch" className="block text-sm font-medium text-gray-700 mb-1">
                        Branch
                      </label>
                      <Field
                        name="branch"
                        type="text"
                        id="branch"
                        placeholder="Enter Branch"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      {submitCount && errors.branch ? (
                        <div className="text-red-500 text-sm mt-1">{errors.branch}</div>
                      ) : (
                        ""
                      )}
                    </div>
                    <div className={submitCount ? (errors.email ? 'has-error' : 'has-success') : ''}>
                      <label htmlFor="email">Email </label>
                      <Field name="email" type="text" id="email" placeholder="Enter Email Address" className="form-input" />
                      {submitCount && errors.email ? <div className="text-danger mt-1">{errors.email}</div> : ''}
                    </div>
                  </div>
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      className="px-6 py-2 bg-blue-600 text-white font-medium rounded-md hover:bg-blue-700"
                    >
                      Add Hospital
                    </button>
                  </div>
                </Form>
              )}
            </Formik>
          </div>
        </div>

        {/* Hospital Overview Card */}


        {/* Hospitals Table */}
        <div className="bg-white rounded-lg shadow-md">
          <div className="p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Hospitals</h3>

              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />

                <input
                  type="text"
                  placeholder="Search by hospital name..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            {/* Hospitals Table */}
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Name
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Address
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Phone
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Email
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      GST No
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Branch
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {currentHospitals.map((hospital) => (
                    <tr key={hospital._id || hospital.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{hospital.name}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{hospital.address}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{hospital.phone}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{hospital.email || "-"}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{hospital.gstNo}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{hospital.branch}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button
                          onClick={() => handleViewHospital(hospital._id || hospital.id)}
                          className="text-green-600 hover:text-green-900 mr-3"
                          title="View Hospital"
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleEditHospital(hospital._id || hospital.id)}
                          className="text-indigo-600 hover:text-indigo-900 mr-3"
                          title="Edit Hospital"
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() =>
                            handleDeleteClick(
                              hospital._id || hospital.id,
                              hospital.name || `Hospital ${hospital._id || hospital.id}`,
                            )
                          }
                          className="text-red-600 hover:text-red-900"
                          title="Delete Hospital"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {currentHospitals.length === 0 && (
                    <tr>
                      <td colSpan={7} className="px-6 py-4 text-center text-gray-500">
                        No hospitals found. Use the form above to add a hospital.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-between mt-6">
                <div className="text-sm text-gray-700">
                  Showing{' '}
                  <span className="font-medium">
                    {indexOfFirst + 1}
                  </span>{' '}
                  to{' '}
                  <span className="font-medium">
                    {Math.min(indexOfLast, hospitals.length)}
                  </span>{' '}
                  of{' '}
                  <span className="font-medium">{hospitals.length}</span>{' '}
                  hospitals
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                    disabled={currentPage === 1}
                    className="px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-500 bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Previous
                  </button>
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                    <button
                      key={page}
                      onClick={() => setCurrentPage(page)}
                      className={`px-3 py-2 border border-gray-300 rounded-md text-sm font-medium ${currentPage === page
                        ? 'z-10 bg-blue-50 border-blue-500 text-blue-600'
                        : 'bg-white text-gray-500 hover:bg-gray-50'
                        }`}
                    >
                      {page}
                    </button>
                  ))}
                  <button
                    onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                    disabled={currentPage === totalPages}
                    className="px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-500 bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Next
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        <ConfirmModal
          open={showDeleteModal}
          onClose={() => setShowDeleteModal(false)}
          onConfirm={handleDeleteConfirm}
          title="Confirm Deletion"
          message={
            deleteItem
              ? `Are you sure you want to delete hospital "${deleteItem.name}"? This action cannot be undone.`
              : "Are you sure you want to delete this hospital?"
          }
        />
      </div>
    </>
  )
}

export default ViewClients