
import type React from "react"
import { useEffect, useState } from "react"
import * as Yup from "yup"
import { FieldArray, Field, Form, Formik, ErrorMessage, type FieldProps } from "formik"
import { Link, useNavigate } from "react-router-dom"
import Select from "react-select"
import { showMessage } from "../../common/ShowMessage"
import { addEnquiryCreateDirectOrder, getAllDealers, getAllEmployees, getAllManufacturer, getAllStates } from "../../../api/index" // Update this path
import AnimatedTrashIcon from "../../common/AnimatedTrashIcon"

// Define interfaces
interface OptionType {
    value: string
    label: string
}

interface MultiSelectFieldProps {
    name: string
    options: OptionType[]
}

interface Service {
    machineType: string
    equipmentNo: string
    workType: string[]
    machineModel: string
    quantity: any
}

type StateType = {
    _id: string;
    name: string; // assuming backend sends `name` for state
};

interface FormValues {
    hospitalName: string
    fullAddress: string
    city: string
    district: string
    state: string
    pinCode: string
    branchName: string
    contactPersonName: string
    emailAddress: string
    contactNumber: string
    designation: string
    specialInstructions: string
    services: Service[]
    additionalServices: Record<string, string | undefined>
}

// Custom component for multi-select field
const MultiSelectField: React.FC<MultiSelectFieldProps> = ({ name, options }) => (
    <Field name={name}>
        {({ field, form }: FieldProps) => (
            <div>
                <Select
                    isMulti
                    options={options}
                    className="w-full" // makes it fill the container
                    classNamePrefix="select"
                    value={options.filter((option) => field.value?.includes(option.value))}
                    onChange={(selectedOptions) =>
                        form.setFieldValue(name, selectedOptions ? selectedOptions.map((option: OptionType) => option.value) : [])
                    }
                    onBlur={() => form.setFieldTouched(name, true)}
                    menuPortalTarget={document.body}
                    styles={{
                        control: (base, state) => ({
                            ...base,
                            minHeight: "38px",
                            fontSize: "0.875rem",
                            padding: "0px 4px",
                            borderColor: state.isFocused ? "#3b82f6" : base.borderColor,
                            boxShadow: state.isFocused ? "0 0 0 0px #3b82f6" : base.boxShadow,
                        }),
                        menuPortal: (base) => ({ ...base, zIndex: 9999 }),
                    }}
                />
                <div className="h-4">
                    <ErrorMessage name={name} component="div" className="text-red-500 text-sm" />
                </div>
            </div>
        )}
    </Field>
)

// Constants
const serviceOptions: string[] = [
    "INSTITUTE REGISTRATION",
    "RSO REGISTRATION, NOMINATION & APPROVAL",
    "DECOMMISSIONING, PRE OWNED PROCUREMENT, QA & LICENSE",
    "PROCUREMENT",
    "TLD BADGE",
    "LEAD SHEET",
    "LEAD GLASS",
    "LEAD APRON",
    "THYROID SHIELD",
    "GONAD SHIELD",
    "OTHERS",
]

const machineOptions: OptionType[] = [


    // "Fixed X-Ray",
    // "Mobile X-Ray",
    // "C-Arm",
    // "Cath Lab/Interventional Radiology",
    // "Mammography",
    // "CT Scan",
    // "PET CT",
    // "CT Simulator",
    // "OPG",
    // "CBCT",
    // "BMD/DEXA",
    // "Dental IOPA",
    // "Dental Hand Held",
    // "O Arm",
    // "KV Imaging (OBI)",
    // "Lead Apron Test",
    // "Thyroid Shield Test",
    // "Gonad Shield Test",
    // "Radiation Survey of Radiation Facility",
    // "Others",

    "Radiography (Fixed)",
    "Radiography (Mobile)",
    "Radiography (Portable)",
    "Radiography and Fluoroscopy",
    "Interventional Radiology",
    "C-Arm",
    "O-Arm",
    "Computed Tomography",
    "Mammography",
    "Dental Cone Beam CT",
    "Ortho Pantomography (OPG)",
    "Dental (Intra Oral)",
    "Dental (Hand-held)",
    "Bone Densitometer (BMD)",
    "KV Imaging (OBI)",
    "Radiography (Mobile) with HT",
    "Lead Apron/Thyroid Shield/Gonad Shield",
    "Others",
].map((label) => ({ label, value: label }))

const specialInstructionsOptions: string[] = [
    "Immediantely (within 1-2 days)",
    "Urgent (Within a week)",
    "Soon (Within 2-3 weeks)",
    "Not urgent (just exploring)",
]

const workTypeOptions: OptionType[] = [
    { value: "Quality Assurance Test", label: "Quality Assurance Test" },
    { value: "License for Operation", label: "License for Operation" },
    { value: "Decommissioning", label: "Decommissioning" },
    { value: "Decommissioning and Recommissioning", label: "Decommissioning and Recommissioning" },
]

const AddEnquiry: React.FC = () => {
    const navigate = useNavigate()
    const [isSubmitting, setIsSubmitting] = useState(false)
    const [employeeOptions, setEmployeeOptions] = useState<{ label: string; value: string }[]>([]);
    const [dealerOptions, setDealerOptions] = useState<{ label: string; value: string }[]>([]);
    const [states, setStates] = useState<StateType[]>([]);
    const [loading, setLoading] = useState(true);
    const [manufacturerOptions, setManufacturerOptions] = useState<{ label: string; value: string }[]>([]);

    useEffect(() => {
        const fetchStates = async () => {
            try {
                const res = await getAllStates();
                // console.log("🚀 ~ fetchStates ~ res:", res.data.data)
                setStates(res.data.data); // backend response shape (adjust key if needed)
            } catch (error) {
                console.error("Failed to fetch states:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchStates();
    }, []);
    useEffect(() => {
        const fetchEmployees = async () => {
            try {
                const res = await getAllEmployees(); // <-- Use your API function
                console.log("🚀 ~ fetchEmployees ~ res:", res)
                // If your API returns data in `res.data` (like `return res.data`), this will already be an array
                const options = res.data.map((emp: any) => ({
                    label: `${emp.name} - employee`,
                    value: emp._id,
                }));
                setEmployeeOptions(options);
            } catch (err) {
                console.error("Failed to load employees", err);
            }
        };

        const fetchDealers = async () => {
            try {
                const res = await getAllDealers();
                const options = res.data.dealers.map((dealer: any) => ({
                    label: `${dealer.name} - dealer`,
                    value: dealer._id,
                }));
                setDealerOptions(options);
            } catch (err) {
                console.error("Failed to load dealers", err);
            }
        };
        const fetchManufacturers = async () => {
            try {
                const res = await getAllManufacturer(); // ✅ call your API
                const data = res.data.data || res.data; // handle both response shapes
                const options = data.map((m: any) => ({
                    label: `${m.name} - manufacturer`,
                    value: m._id,
                }));
                // ✅ Append them to the dropdown by merging with existing options
                setManufacturerOptions(options);
            } catch (err) {
                console.error("Failed to load manufacturers", err);
            }
        };

        fetchEmployees();
        fetchDealers();
        fetchManufacturers();

    }, []);

    // Yup validation schema
    const SubmittedForm = Yup.object().shape({
        leadOwner: Yup.string().required("Please fill the Field"),
        hospitalName: Yup.string().required("Please fill the Field"),
        fullAddress: Yup.string().required("Please fill the Field"),
        city: Yup.string().required("Please fill the Field"),
        district: Yup.string(),
        state: Yup.string().required("Please fill the Field"),
        pinCode: Yup.string()
            .matches(/^\d{6}$/, "PIN Code must be exactly 6 digits")
            .required("PIN Code is required"),
        branchName: Yup.string(),
        contactPersonName: Yup.string().required("Please fill the Field"),
        emailAddress: Yup.string().email("Invalid email").required("Please fill the Email"),
        contactNumber: Yup.string()
            .matches(/^\d{10}$/, "Contact Number must be exactly 10 digits")
            .required("Contact Number is required"),
        designation: Yup.string().required("Please fill the Field"),
        specialInstructions: Yup.string(),
        services: Yup.array()
            .of(
                Yup.object().shape({
                    machineType: Yup.string()
                        .required("Machine Type is required")
                        .test(
                            "not-others-without-custom",
                            "Please specify the custom machine type",
                            function (value) {
                                const { customMachineType } = this.parent;
                                if (value === "Others") {
                                    return !!customMachineType && customMachineType.trim().length > 0;
                                }
                                return true;
                            }
                        ),
                    customMachineType: Yup.string().when("machineType", {
                        is: "Others",
                        then: (schema) => schema.required("Please specify the machine type").min(2, "Too short"),
                        otherwise: (schema) => schema.optional().nullable(),
                    }),
                    quantity: Yup.number()
                        .typeError("Must be a number")
                        .positive("Must be greater than 0")
                        .integer("Must be a whole number")
                        .required("Quantity is required"),
                    workType: Yup.array().min(1, "At least one work type is required"),
                    equipmentNo: Yup.string(),
                    machineModel: Yup.string(),
                })
            )
            .min(1, "At least one service is required"),
        // .test(
        //     "unique-machineType",
        //     "Each Machine Type must be unique",
        //     (services) => {
        //         if (!services) return true;
        //         const machineTypes = services.map(s => s.machineType);
        //         const uniqueTypes = new Set(machineTypes);
        //         return uniqueTypes.size === machineTypes.length;
        //     }
        // ),
        additionalServices: Yup.object().shape(
            serviceOptions.reduce((schema, service) => {
                return { ...schema, [service]: Yup.string().nullable() };
            }, {})
        ),
    });

    // Form submission handler
    const submitForm = async (values: FormValues, { setSubmitting, resetForm }: any) => {
        try {
            setIsSubmitting(true)
            // Generate enquiryID (e.g., ENQ001) - replace with actual logic to fetch existing enquiries
            const enquiryCount = 1 // Placeholder: Replace with actual count from enquiriesData or API
            // const newEnquiryID = `ENQ${String(enquiryCount).padStart(3, "0")}`
            const submissionValues = { ...values, }
            console.log("Submitting form with values:", submissionValues)
            // Make API call
            const response = await addEnquiryCreateDirectOrder(submissionValues)
            console.log("API Response:", response)
            // Show success message
            showMessage("Enquiry submitted successfully!", "success")
            // Reset form
            resetForm()
            // Navigate to enquiry list
            navigate("/admin/enquiry")
        } catch (error: any) {
            console.error("Error submitting enquiry:", error)

            // Show error message
            const errorMessage = error?.message || "Failed to submit enquiry. Please try again."
            showMessage(errorMessage, "error")
        } finally {
            setIsSubmitting(false)
            setSubmitting(false)
        }
    }

    return (
        <>
            <ol className="flex text-gray-500 font-semibold dark:text-white-dark mb-4">
                <li>
                    <Link to="/" className="hover:text-gray-500/70 dark:hover:text-white-dark/70">
                        Dashboard
                    </Link>
                </li>
                <li className="before:w-1 before:h-1 before:rounded-full before:bg-primary before:inline-block before:relative before:-top-0.5 before:mx-4">
                    <Link to="/admin/enquiry" className="text-primary">
                        Enquiry
                    </Link>
                </li>
                <li className="before:w-1 before:h-1 before:rounded-full before:bg-primary before:inline-block before:relative before:-top-0.5 before:mx-4">
                    <Link to="#" className="hover:text-gray-500/70 dark:hover:text-white-dark/70">
                        Add Enquiry
                    </Link>
                </li>
            </ol>
            <h5 className="font-semibold text-lg mb-4">Enquiry Form</h5>
            <Formik
                initialValues={{
                    leadOwner: "",
                    hospitalName: "",
                    fullAddress: "",
                    city: "",
                    district: "",
                    state: "",
                    pinCode: "",
                    branchName: "",
                    contactPersonName: "",
                    emailAddress: "",
                    contactNumber: "",
                    designation: "",
                    specialInstructions: "",
                    services: [{ machineType: "", equipmentNo: "", workType: [], machineModel: "", quantity: "" }],
                    additionalServices: serviceOptions.reduce(
                        (acc, service) => {
                            acc[service] = undefined
                            return acc
                        },
                        {} as Record<string, string | undefined>,
                    ),
                    attachment: "",
                }}
                validationSchema={SubmittedForm}
                onSubmit={submitForm}
            >
                {({ errors, submitCount, values, setFieldValue, isSubmitting: formikSubmitting }) => (
                    <Form className="space-y-5">
                        {/* Basic Details */}
                        <div className="panel">
                            <h5 className="font-semibold text-lg mb-4">Basic Details</h5>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-4">
                                <div className={submitCount && errors.leadOwner ? "has-error" : submitCount ? "has-success" : ""}>
                                    <label htmlFor="leadOwner">Lead Owner</label>
                                    <Field as="select" name="leadOwner" className="form-input">
                                        <option value="">Select Lead Owner</option>

                                        {employeeOptions.map((option) => (
                                            <option key={option.value} value={option.value}>
                                                {option.label}
                                            </option>
                                        ))}

                                        {dealerOptions.map((option) => (
                                            <option key={option.value} value={option.value}>
                                                {option.label}
                                            </option>
                                        ))}


                                        {manufacturerOptions.map((option) => (
                                            <option key={option.value} value={option.value}>
                                                {option.label}
                                            </option>
                                        ))}

                                    </Field>

                                    {submitCount && errors.leadOwner ? (
                                        <div className="text-danger mt-1">{errors.leadOwner}</div>
                                    ) : null}
                                </div>


                                <div className={submitCount && errors.hospitalName ? "has-error" : submitCount ? "has-success" : ""}>
                                    <label htmlFor="hospitalName">Hospital Name</label>
                                    <Field
                                        name="hospitalName"
                                        type="text"
                                        id="hospitalName"
                                        placeholder="Enter Hospital Name"
                                        className="form-input"
                                    />
                                    {submitCount && errors.hospitalName ? (
                                        <div className="text-danger mt-1">{errors.hospitalName}</div>
                                    ) : null}
                                </div>
                                <div className={submitCount && errors.fullAddress ? "has-error" : submitCount ? "has-success" : ""}>
                                    <label htmlFor="fullAddress">Full Address</label>
                                    <Field
                                        name="fullAddress"
                                        type="text"
                                        id="fullAddress"
                                        placeholder="Enter Full Address"
                                        className="form-input"
                                    />
                                    {submitCount && errors.fullAddress ? (
                                        <div className="text-danger mt-1">{errors.fullAddress}</div>
                                    ) : null}
                                </div>
                                <div className={submitCount && errors.city ? "has-error" : submitCount ? "has-success" : ""}>
                                    <label htmlFor="city">City</label>
                                    <Field name="city" type="text" id="city" placeholder="Enter City Name" className="form-input" />
                                    {submitCount && errors.city ? <div className="text-danger mt-1">{errors.city}</div> : null}
                                </div>
                                <div className={submitCount && errors.district ? "has-error" : submitCount ? "has-success" : ""}>
                                    <label htmlFor="district">District</label>
                                    <Field
                                        name="district"
                                        type="text"
                                        id="district"
                                        placeholder="Enter District Name"
                                        className="form-input"
                                    />
                                    {submitCount && errors.district ? <div className="text-danger mt-1">{errors.district}</div> : null}
                                </div>
                                <div
                                    className={
                                        submitCount && errors.state ? "has-error" : submitCount ? "has-success" : ""
                                    }
                                >
                                    <label htmlFor="state">State</label>
                                    <Field
                                        as="select"
                                        name="state"
                                        id="state"
                                        className="form-input"
                                        disabled={loading}
                                    >
                                        <option value="">Select State</option>
                                        {states.map((st, index) => (
                                            <option key={index} value={String(st)}>
                                                {String(st)}
                                            </option>
                                        ))}
                                    </Field>
                                    {submitCount && errors.state ? (
                                        <div className="text-danger mt-1">{errors.state}</div>
                                    ) : null}
                                </div>
                                <div className={submitCount && errors.pinCode ? "has-error" : submitCount ? "has-success" : ""}>
                                    <label htmlFor="pinCode">PIN Code</label>
                                    <Field
                                        name="pinCode"
                                        type="text"
                                        id="pinCode"
                                        placeholder="Enter PIN Code"
                                        className="form-input"
                                        maxLength={6} // ✅ Prevent more than 6 digits
                                        onInput={(e: React.ChangeEvent<HTMLInputElement>) => {
                                            e.target.value = e.target.value.replace(/[^0-9]/g, ""); // ✅ Allow only numbers
                                        }}
                                    />
                                    {submitCount && errors.pinCode ? (
                                        <div className="text-danger mt-1">{errors.pinCode}</div>
                                    ) : null}
                                </div>

                                <div className={submitCount && errors.branchName ? "has-error" : submitCount ? "has-success" : ""}>
                                    <label htmlFor="branchName">Branch Name</label>
                                    <Field name="branchName" type="text" id="branchName" placeholder="Enter Branch Name" className="form-input" />
                                    {submitCount && errors.branchName ? <div className="text-danger mt-1">{errors.branchName}</div> : null}
                                </div>
                                <div className={submitCount && errors.contactPersonName ? "has-error" : submitCount ? "has-success" : ""}>
                                    <label htmlFor="contactPersonName">Contact Person Name</label>
                                    <Field
                                        name="contactPersonName"
                                        type="text"
                                        id="contactPersonName"
                                        placeholder="Enter Contact Person Name"
                                        className="form-input"
                                    />
                                    {submitCount && errors.contactPersonName ? (
                                        <div className="text-danger mt-1">{errors.contactPersonName}</div>
                                    ) : null}
                                </div>
                                <div className={submitCount && errors.emailAddress ? "has-error" : submitCount ? "has-success" : ""}>
                                    <label htmlFor="emailAddress">Email Address</label>
                                    <Field
                                        name="emailAddress"
                                        type="text"
                                        id="emailAddress"
                                        placeholder="Enter Email Address"
                                        className="form-input"
                                    />
                                    {submitCount && errors.emailAddress ? (
                                        <div className="text-danger mt-1">{errors.emailAddress}</div>
                                    ) : null}
                                </div>
                                <div className={submitCount && errors.contactNumber ? "has-error" : submitCount ? "has-success" : ""}>
                                    <label htmlFor="contactNumber">Contact Number</label>
                                    <Field
                                        name="contactNumber"
                                        type="text"
                                        id="contactNumber"
                                        placeholder="Enter Contact Number"
                                        className="form-input"
                                        maxLength={10}
                                        onInput={(e: React.ChangeEvent<HTMLInputElement>) => {
                                            e.target.value = e.target.value.replace(/[^0-9]/g, "");
                                        }}
                                    />
                                    {submitCount && errors.contactNumber ? (
                                        <div className="text-danger mt-1">{errors.contactNumber}</div>
                                    ) : null}
                                </div>
                                <div className={submitCount && errors.designation ? "has-error" : submitCount ? "has-success" : ""}>
                                    <label htmlFor="designation">Designation</label>
                                    <Field
                                        name="designation"
                                        type="text"
                                        id="designation"
                                        placeholder="Enter Designation"
                                        className="form-input"
                                    />
                                    {submitCount && errors.designation ? (
                                        <div className="text-danger mt-1">{errors.designation}</div>
                                    ) : null}
                                </div>
                            </div>
                        </div>

                        {/* Services Section */}
                        <div className="panel">
                            <h5 className="font-semibold text-lg mb-4">Services</h5>


                            <FieldArray name="services">
                                {({ push, remove }) => (
                                    <>
                                        {values.services.map((service, index) => {
                                            const selectedMachineType = service.machineType;
                                            const isOthersSelected = selectedMachineType === "Others" ||
                                                (!machineOptions.map(o => o.value).includes(selectedMachineType) && selectedMachineType);

                                            return (
                                                <div key={index} className="border border-gray-200 rounded-lg p-5 mb-6 relative">
                                                    {values.services.length > 1 && (
                                                        <button
                                                            type="button"
                                                            onClick={() => remove(index)}
                                                            className="absolute top-2 right-2 text-red-500 hover:text-red-700 z-10"
                                                        >
                                                            <AnimatedTrashIcon onClick={() => remove(index)} />
                                                        </button>
                                                    )}

                                                    <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
                                                        {/* Machine Type Dropdown */}
                                                        <div className="md:col-span-4">
                                                            <label className="text-sm font-semibold text-gray-700">Machine Type</label>
                                                            <Field
                                                                as="select"
                                                                name={`services.${index}.machineType`}
                                                                className="form-select w-full"
                                                                onChange={(e: React.ChangeEvent<HTMLSelectElement>) => {
                                                                    const value = e.target.value;
                                                                    if (value !== "Others") {
                                                                        setFieldValue(`services.${index}.machineType`, value);
                                                                    } else {
                                                                        // User selected "Others" → keep "Others" temporarily, but allow typing
                                                                        setFieldValue(`services.${index}.machineType`, "Others");
                                                                    }
                                                                }}
                                                            >
                                                                <option value="">Select Machine Type</option>
                                                                {machineOptions.map((option) => (
                                                                    <option key={option.value} value={option.value}>
                                                                        {option.label}
                                                                    </option>
                                                                ))}
                                                            </Field>
                                                            <ErrorMessage
                                                                name={`services.${index}.machineType`}
                                                                component="div"
                                                                className="text-red-500 text-sm mt-1"
                                                            />
                                                        </div>

                                                        {/* Show custom input if "Others" is selected OR user has typed a custom value */}
                                                        {isOthersSelected && (
                                                            <div className="md:col-span-4">
                                                                <label className="text-sm font-semibold text-gray-700">
                                                                    Specify Other Machine Type <span className="text-red-500">*</span>
                                                                </label>
                                                                <Field
                                                                    type="text"
                                                                    name={`services.${index}.machineType`}  // ← Important: bind directly to machineType!
                                                                    placeholder="e.g. LINAC, Brachytherapy, etc."
                                                                    className="form-input w-full mt-1"
                                                                    value={selectedMachineType === "Others" ? "" : selectedMachineType}
                                                                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                                                        const customValue = e.target.value.trim();
                                                                        setFieldValue(`services.${index}.machineType`, customValue || "Others");
                                                                    }}
                                                                />
                                                                {/* {selectedMachineType === "Others" && (
                                                                    <p className="text-xs text-amber-600 mt-1">
                                                                        Please type the machine type
                                                                    </p>
                                                                )} */}
                                                                <ErrorMessage
                                                                    name={`services.${index}.machineType`}
                                                                    component="div"
                                                                    className="text-red-500 text-sm mt-1"
                                                                />
                                                            </div>
                                                        )}

                                                        {/* Quantity */}
                                                        <div className="md:col-span-2">
                                                            <label className="text-sm font-semibold text-gray-700">Quantity</label>
                                                            <Field
                                                                type="number"
                                                                name={`services.${index}.quantity`}
                                                                placeholder="Qty"
                                                                min="1"
                                                                className="form-input w-full"
                                                            />
                                                            <ErrorMessage name={`services.${index}.quantity`} component="div" className="text-red-500 text-sm" />
                                                        </div>

                                                        {/* Equipment No. */}
                                                        <div className="md:col-span-2">
                                                            <label className="text-sm font-semibold text-gray-700">Equipment ID/Serial No.</label>
                                                            <Field
                                                                type="text"
                                                                name={`services.${index}.equipmentNo`}
                                                                placeholder="Enter ID"
                                                                className="form-input w-full"
                                                            />
                                                        </div>

                                                        {/* Work Type */}
                                                        <div className="md:col-span-4">
                                                            <label className="text-sm font-semibold text-gray-700">Type Of Work</label>
                                                            <MultiSelectField name={`services.${index}.workType`} options={workTypeOptions} />
                                                        </div>

                                                        {/* Machine Model */}
                                                        <div className="md:col-span-2">
                                                            <label className="text-sm font-semibold text-gray-700">Machine Model</label>
                                                            <Field
                                                                type="text"
                                                                name={`services.${index}.machineModel`}
                                                                placeholder="Enter Model"
                                                                className="form-input w-full"
                                                            />
                                                        </div>
                                                    </div>
                                                </div>
                                            );
                                        })}

                                        {/* Add button */}
                                        <button
                                            type="button"
                                            onClick={() =>
                                                push({
                                                    machineType: "",
                                                    equipmentNo: "",
                                                    workType: [],
                                                    machineModel: "",
                                                    quantity: "",
                                                })
                                            }
                                            className="btn btn-primary w-full sm:w-auto"
                                        >
                                            + Add Another Machine
                                        </button>

                                        {errors.services && typeof errors.services === "string" && (
                                            <div className="text-red-500 text-sm mt-2">{errors.services}</div>
                                        )}
                                    </>
                                )}
                            </FieldArray>
                        </div>

                        {/* Additional Services */}
                        <div className="panel">
                            <h5 className="font-semibold text-lg mb-4">Additional Services</h5>
                            {serviceOptions.map((service) => (
                                <div
                                    key={service}
                                    className="grid grid-cols-1 sm:grid-cols-3 items-start gap-4 py-2 border-b border-gray-200"
                                >
                                    <div className="flex items-center gap-2">
                                        <input
                                            type="checkbox"
                                            checked={values.additionalServices[service] !== undefined}
                                            onChange={() => {
                                                if (values.additionalServices[service] !== undefined) {
                                                    setFieldValue(`additionalServices.${service}`, undefined) // Uncheck
                                                } else {
                                                    setFieldValue(`additionalServices.${service}`, "") // Check with empty string
                                                }
                                            }}
                                            className={`form-checkbox h-5 w-5 transition-colors duration-200 ${values.additionalServices[service] !== undefined ? "text-blue-600" : "text-gray-400"}`}
                                        />
                                        <span>{service}</span>
                                    </div>
                                    {values.additionalServices[service] !== undefined && (
                                        <div className="sm:col-span-2 mt-2 sm:mt-0">
                                            <Field
                                                type="text"
                                                name={`additionalServices.${service}`}
                                                placeholder="Enter info..."
                                                className="form-input w-full"
                                            />
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>

                        {/* specialInstructions */}
                        <div className="panel">
                            <h5 className="font-semibold text-lg mb-4">Special Instructions</h5>
                            {/* Side-by-side layout */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {/* Special Instructions Field */}
                                <div className={submitCount && errors.specialInstructions ? "has-error" : submitCount ? "has-success" : ""}>
                                    <label htmlFor="specialInstructions" className="block mb-1 font-medium">
                                        Special Instructions
                                    </label>
                                    <Field
                                        name="specialInstructions"
                                        type="text"
                                        id="specialInstructions"
                                        placeholder="Enter special instruction"
                                        className="form-input"
                                    />
                                    {submitCount > 0 && errors.specialInstructions && <p className="text-red-500 text-sm mt-1">{errors.specialInstructions}</p>}
                                </div>
                                {/* Attachment Upload Field */}
                                <div className={submitCount && errors.attachment ? "has-error" : submitCount ? "has-success" : ""}>
                                    <label htmlFor="attachment" className="block mb-1 font-medium">
                                        Attach QA Requirement List
                                    </label>
                                    {/* <Field name="attachment" type="file" id="attachment" className="form-input" /> */}
                                    <input
                                        id="attachment"
                                        name="attachment"
                                        type="file"
                                        className="form-input"
                                        onChange={(event) => {
                                            if (event.currentTarget.files) {
                                                setFieldValue("attachment", event.currentTarget.files[0]);
                                            }
                                        }}
                                    />

                                    {submitCount > 0 && errors.attachment && <div className="text-danger mt-1">{errors.attachment}</div>}
                                </div>
                            </div>
                        </div>

                        {/* Submit Button */}
                        <div className="w-full mb-6 flex justify-end">
                            <button type="submit" className="btn btn-success mt-4" disabled={isSubmitting || formikSubmitting}>
                                {isSubmitting ? "Submitting..." : "Submit Enquiry"}
                            </button>
                        </div>
                    </Form>
                )}
            </Formik>
        </>
    )
}

export default AddEnquiry
