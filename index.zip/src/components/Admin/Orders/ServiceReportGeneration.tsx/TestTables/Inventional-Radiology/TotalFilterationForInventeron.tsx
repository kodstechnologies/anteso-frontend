import React from 'react'

const TotalFilterationForInventeron = () => {
  return (
    <div>TotalFilterationForInventeron</div>
  )
}

export default TotalFilterationForInventeron