import React from 'react'

const AccuracyOfOperatingPotential = () => {
  return (
    <div>AccuracyOfOperatingPotential</div>
  )
}

export default AccuracyOfOperatingPotential