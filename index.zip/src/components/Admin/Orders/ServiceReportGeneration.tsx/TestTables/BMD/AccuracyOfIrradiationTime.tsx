import React from 'react'

const AccuracyOfIrradiationTime = () => {
  return (
    <div>AccuracyOfIrradiationTime</div>
  )
}

export default AccuracyOfIrradiationTime