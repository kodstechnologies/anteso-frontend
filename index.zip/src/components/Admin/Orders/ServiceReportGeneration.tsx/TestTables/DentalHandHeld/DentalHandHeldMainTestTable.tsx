import React from 'react'

const DentalHandHeldMainTestTable = () => {
  return (
    <div>DentalHandHeldMainTestTable</div>
  )
}

export default DentalHandHeldMainTestTable
