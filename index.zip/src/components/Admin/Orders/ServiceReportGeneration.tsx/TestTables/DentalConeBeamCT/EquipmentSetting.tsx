import React from 'react'

const EquipmentSetting = () => {
  return (
    <div>EquipmentSetting</div>
  )
}

export default EquipmentSetting