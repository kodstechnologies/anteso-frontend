import React from 'react'

const TotalFilteration = () => {
  return (
    <div>TotalFilteration</div>
  )
}

export default TotalFilteration