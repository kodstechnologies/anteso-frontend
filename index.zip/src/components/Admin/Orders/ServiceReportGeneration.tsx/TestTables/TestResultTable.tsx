import React from 'react'

const TestResultTable = () => {
  return (
    <div>TestResultTable</div>
  )
}

export default TestResultTable