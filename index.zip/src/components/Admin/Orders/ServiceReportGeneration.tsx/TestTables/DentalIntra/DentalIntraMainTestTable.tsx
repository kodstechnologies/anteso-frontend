import React from 'react'

const DenTalIntraMainTestTable = () => {
  return (
    <div>DenralIntraMainTestTable</div>
  )
}

export default DenTalIntraMainTestTable