import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import Select from 'react-select';
import AnimateHeight from 'react-animate-height';
import { useState } from 'react';
import IconCaretDown from '../../Icon/IconCaretDown';
import Breadcrumb, { BreadcrumbItem } from '../../common/Breadcrumb';
import IconHome from '../../Icon/IconHome';
import IconBox from '../../Icon/IconBox';
import IconBook from '../../Icon/IconBook';
import { paymentdata } from '../../../data'; // or fetch via API
import PyamentPNG from '../../../../public/assets/images/payment.png'
import FadeInModal from '../../../components/common/FadeInModal'; // adjust path if needed
import { InformationCircleIcon } from '@heroicons/react/24/outline';
import IconEye from '../../Icon/IconEye';
import MachineImage from '../../../assets/machine.jpg'
import DymmyReport from '../../../../public/assets/dummy-report.jpg'
import ExpenseAndAccountDetails from './ExpenseAndAccountDetails';
import CourierDetails from './CourierDetails';
import AdditionalServices from './AdditionalServices';
import ServiceDetails from './ServiceDetails';
import { getBasicDetailsByOrderId, getPdfForAcceptQuotation, getWorkOrderCopy } from '../../../api';
import ServiceDetails2 from './ServiceDetails2'
import ServicesCard from './ServiceDetails2';

// Define interfaces
interface OptionType {
    value: string;
    label: string;
}
interface HospitalDetails {
    hospitalName: string;
    fullAddress: string;
    city: string;
    district: string;
    state: string;
    pinCode: string;
    contactPersonName: string;
    emailAddress: string;
    contactNumber: string;
    designation: string;
}


// Constants
const employeeOptions: OptionType[] = [
    { value: 'Employee 1', label: 'Employee 1' },
    { value: 'Employee 2', label: 'Employee 2' },
    { value: 'Employee 3', label: 'Employee 3' },
    { value: 'Employee 4', label: 'Employee 4' },
];
const aditionalServices = [
    'INSTITUTE REGISTRATION', 'RSO REGISTRATION, NOMINATION & APPROVAL', 'DECOMMISSIONING, PRE OWNED PROCUREMENT, QA & LICENSE', 'PROCUREMENT', 'TLD BADGE', 'THYROID SHIELD', 'LEAD APRON', 'LEAD GLASS', 'LEAD SHEET']

const View = () => {
    const [active, setActive] = useState<string>('1');
    const [isAddingCourier, setIsAddingCourier] = useState(false);
    // const [details, setDetails] = useState<HospitalDetails | null>(null);
    const [pdfUrl, setPdfUrl] = useState<string>(''); // ✅ state for PDF URL
    const [workOrderCopyUrl, setWorkOrderCopyUrl] = useState<string>('');

    const togglePara = (value: string) => {
        setActive((oldValue) => {
            return oldValue === value ? '' : value;
        });
    };
    const [selectedRow, setSelectedRow] = useState(null);
    const [openModal, setOpenModal] = useState(false);
    const [openMachineModal, setOpenMachineModal] = useState(false)
    const [openVerificationModal, setOpenVerificationModal] = useState(false)
    const { orderId } = useParams(); // Assuming you're using a dynamic route like /orders/:orderId
    // console.log("🚀 ~ View ~ orderId:", orderId)
    const [details, setDetails] = useState<HospitalDetails | null>(null);

    if (!orderId) {
        return <div className="text-gray-600 p-6">Order ID not found.</div>;
    }
    const breadcrumbItems: BreadcrumbItem[] = [
        { label: 'Dashboard', to: '/', icon: <IconHome /> },
        { label: 'Orders', to: '/admin/orders', icon: <IconBox /> },
        { label: 'View', icon: <IconBook /> },
    ];
    useEffect(() => {
        const fetchData = async () => {
            if (!orderId) return;

            try {
                const resDetails = await getBasicDetailsByOrderId(orderId);
                setDetails(resDetails.data);

                const resPdf = await getPdfForAcceptQuotation(orderId);
                setPdfUrl(resPdf.data.pdfUrl || ''); // ✅ set PDF URL
            } catch (error) {
                console.error("Failed to fetch data:", error);
            }
        };
        fetchData();
    }, [orderId]);
    useEffect(() => {
        const fetchData = async () => {
            if (!orderId) return;

            try {
                const resDetails = await getBasicDetailsByOrderId(orderId);
                setDetails(resDetails.data);

                const resPdf = await getPdfForAcceptQuotation(orderId);
                setPdfUrl(resPdf.data.pdfUrl || '');

                const resWorkOrder = await getWorkOrderCopy(orderId);
                console.log("🚀 ~ fetchData ~ resWorkOrder:", resWorkOrder)
                setWorkOrderCopyUrl(resWorkOrder || '');
            } catch (error) {
                console.error("Failed to fetch data:", error);
            }
        };
        fetchData();
    }, [orderId]);
    const handleViewPdf = async () => {
        if (!orderId) return;
        try {
            const res = await getPdfForAcceptQuotation(orderId);

            // Assuming res.data.url contains the PDF URL
            const pdfUrl = res.data.pdfUrl;
            window.open(pdfUrl, '_blank');
        } catch (error) {
            console.error("Failed to view PDF:", error);
            alert("Failed to open PDF. Please try again.");
        }
    };



    if (!details) return <div className="text-gray-600 p-6">Loading...</div>;
    const fields = [
        { label: 'Hospital Name', value: details.hospitalName },
        { label: 'Address', value: details.fullAddress },
        { label: 'City', value: details.city },
        { label: 'State', value: details.state },
        { label: 'Pin Code', value: details.pinCode },
        { label: 'Contact Person Name', value: details.contactPersonName },
        { label: 'Email Address', value: details.emailAddress },
        { label: 'Contact Number', value: details.contactNumber },
        { label: 'Designation', value: details.designation },
    ];
    return (
        <div>
            <Breadcrumb items={breadcrumbItems} />

            {/* <h1 className="text-2xl font-bold text-gray-800 mb-6">Order Details</h1> */}
            {/* basic details */}
            <div className="bg-white p-6 rounded-lg shadow-lg">
                <h5 className="text-lg font-bold text-gray-800 mb-6">Basic Details</h5>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 text-sm text-gray-700">
                    {fields.map((field, idx) => (
                        <div key={idx} className="bg-gray-50 border border-gray-200 rounded-lg p-4 shadow-sm">
                            <div className="text-xs uppercase text-gray-500 font-semibold mb-1">
                                {field.label}
                            </div>
                            <div className="text-gray-800 font-medium">{field.value}</div>
                        </div>
                    ))}
                </div>
            </div>
            {/* ✅ Only show if pdfUrl exists and is not empty */}
            {pdfUrl && pdfUrl.trim() !== '' && (
                <div className="bg-white p-4 rounded-lg shadow-md mt-4">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-blue-100 text-blue-600 flex items-center justify-center rounded-lg">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                                </svg>
                            </div>
                            <div>
                                <p className="text-gray-800 font-medium text-sm">Customer Uploaded PDF</p>
                                <p className="text-xs text-gray-500">Click to view PDF</p>
                            </div>
                        </div>
                        <button
                            onClick={handleViewPdf}
                            className="px-3 py-1.5 bg-blue-600 text-white text-sm rounded shadow hover:bg-blue-700 transition"
                        >
                            View
                        </button>
                    </div>
                </div>
            )}
            {/* ✅ Show Work Order Copy only if available */}
            {workOrderCopyUrl && workOrderCopyUrl.trim() !== '' && (
                <div className="bg-white p-4 rounded-lg shadow-md mt-4">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-green-100 text-green-600 flex items-center justify-center rounded-lg">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                                </svg>
                            </div>
                            <div>
                                <p className="text-gray-800 font-medium text-sm">Work Order Copy</p>
                                <p className="text-xs text-gray-500">Click to view uploaded file</p>
                            </div>
                        </div>
                        <button
                            onClick={() => window.open(workOrderCopyUrl, '_blank')}
                            className="px-3 py-1.5 bg-green-600 text-white text-sm rounded shadow hover:bg-green-700 transition"
                        >
                            View
                        </button>
                    </div>
                </div>
            )}


            {/* ✅ Only show if pdfUrl exists and is not empty */}


            {/* Service details */}
            <ServiceDetails2 orderId={orderId} />
            {/* <ServicesCardDemo orderId={orderId} /> */}
            <div className="bg-white p-6 rounded-lg shadow-lg mt-5">
                <div className="space-y-4">
                    <AdditionalServices />
                    <div className="bg-white p-6 rounded-lg shadow-lg mt-6">
                        <CourierDetails orderId={orderId} />
                    </div>
                    <FadeInModal open={openModal} onClose={() => setOpenModal(false)} title="Payment Screenshot">
                        <img
                            src={PyamentPNG}
                            alt="Payment Screenshot"
                            className="w-full rounded-lg shadow-md object-contain h-80"
                        />
                    </FadeInModal>
                    <FadeInModal open={openMachineModal} onClose={() => setOpenMachineModal(false)} title="Machine Image">
                        <img
                            src={MachineImage}
                            alt="Machine Image"
                            className="w-full rounded-lg shadow-md object-contain h-80"
                        />
                    </FadeInModal>
                    <FadeInModal open={openVerificationModal} onClose={() => setOpenVerificationModal(false)} title="Verification Image">
                        <img
                            src={DymmyReport}
                            alt="Verification Image"
                            className="w-full rounded-lg shadow-md object-contain h-80"
                        />
                    </FadeInModal>
                    <ExpenseAndAccountDetails orderId={orderId} />
                </div>
            </div>
        </div>
    );
};

export default View;    
